INSERT INTO Users VALUES ('E'||TO_CHAR(Employee_id_Sequence_query.NEXTVAL,'FM00'),?,?,?,?,?,?,?);

INSERT INTO Users VALUES ('C'||TO_CHAR(Customer_id_Sequence_query.NEXTVAL,'FM00'),?,?,?,?,?,?,?)";

INSERT INTO Hotel VALUES ('H'||TO_CHAR(Hotel_id_Sequence_query.NEXTVAL,'FM00'),'Kolkata','Nilachal','Baguiati','Near Airport',1500,'9876543201','9874102563','3*','Nl@gmail.com','225413300265');
INSERT INTO Hotel VALUES ('H'||TO_CHAR(Hotel_id_Sequence_query.NEXTVAL,'FM00'),'Kolkata','Senses','Shyambazar','Near Market',1600,'9876543001','9874102063','3*','Ss@gmail.com','225410300265');
INSERT INTO Hotel VALUES ('H'||TO_CHAR(Hotel_id_Sequence_query.NEXTVAL,'FM00'),'Kolkata','Divine','Beliaghata','At Centre',1400,'9876143201','9874112563','2*','Dv@gmail.com','225413310265');
INSERT INTO Hotel VALUES ('H'||TO_CHAR(Hotel_id_Sequence_query.NEXTVAL,'FM00'),'Kolkata','Mercy','Lake Town','Near Theatre',1200,'9876549201','9874902563','2*','Mr@gmail.com','225423300265');

INSERT INTO Hotel VALUES ('H'||TO_CHAR(Hotel_id_Sequence_query.NEXTVAL,'FM00'),'Puri','Sea Gull','Swargaddwar','Near Beach',1700,'9856523201','9854902563','2*','Sg@gmail.com','225493003265');
INSERT INTO Hotel VALUES ('H'||TO_CHAR(Hotel_id_Sequence_query.NEXTVAL,'FM00'),'Puri','Park','Chilka','Near Market',1100,'9876543261','9824169563','2*','Pk@gmail.com','225413630665');
INSERT INTO Hotel VALUES ('H'||TO_CHAR(Hotel_id_Sequence_query.NEXTVAL,'FM00'),'Puri','Hotel Puri','Swargaddwar','Near Beach',1800,'9826543207','9854192567','3*','Hp@gmail.com','205433303265');
INSERT INTO Hotel VALUES ('H'||TO_CHAR(Hotel_id_Sequence_query.NEXTVAL,'FM00'),'Puri','Sonali','Chilka','Near Market',1300,'9826543261','9874162963','3*','Sn@gmail.com','225413336065');

INSERT INTO Hotel VALUES ('H'||TO_CHAR(Hotel_id_Sequence_query.NEXTVAL,'FM00'),'Mumbai','Hotel Taj','Marina Drive','Near Beach',2200,'9856243201','9254102563','4*','Ht@gmail.com','205493302265');
INSERT INTO Hotel VALUES ('H'||TO_CHAR(Hotel_id_Sequence_query.NEXTVAL,'FM00'),'Mumbai','Samilton','Dadar','Near Market',2100,'9870543261','9874162503','3*','S@gmail.com','225413330665');
INSERT INTO Hotel VALUES ('H'||TO_CHAR(Hotel_id_Sequence_query.NEXTVAL,'FM00'),'Mumbai','Lind Set','Gur Gaon','Near Mall',2500,'9896543201','9855102563','2*','Sg@gmail.com','225393343265');
INSERT INTO Hotel VALUES ('H'||TO_CHAR(Hotel_id_Sequence_query.NEXTVAL,'FM00'),'Mumbai','Freedom','Chilka','Near Market',2700,'9876593261','9875162563','2*','Sn@gmail.com','225413338635');

INSERT INTO Hotel VALUES ('H'||TO_CHAR(Hotel_id_Sequence_query.NEXTVAL,'FM00'),'Chennai','Prestige','Swargaddwar','Near Beach',1500,'8856543201','8854102563','3*','Pg@gmail.com','225493303265');
INSERT INTO Hotel VALUES ('H'||TO_CHAR(Hotel_id_Sequence_query.NEXTVAL,'FM00'),'Chennai','Geetanjali','Chilka','Near Market',2300,'6876543261','7874162563','3*','Gt@gmail.com','2254133306657');
INSERT INTO Hotel VALUES ('H'||TO_CHAR(Hotel_id_Sequence_query.NEXTVAL,'FM00'),'Chennai','Ethnic','Swargaddwar','Near Beach',2800,'9756543201','6854102563','4*','Et@gmail.com','225493307265');
INSERT INTO Hotel VALUES ('H'||TO_CHAR(Hotel_id_Sequence_query.NEXTVAL,'FM00'),'Chennai','Lytton','Chilka','Near Market',3000,'7876543261','9874162563','4*','Ly@gmail.com','225413330765');

INSERT INTO RoomDetails VALUES ('H01','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'101','AC',1500,'1');
INSERT INTO RoomDetails VALUES ('H01','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'102','NON-AC',1200,'1');
INSERT INTO RoomDetails VALUES ('H01','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'103','AC',1600,'1');
INSERT INTO RoomDetails VALUES ('H01','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'104','NON-AC',1300,'1');

INSERT INTO RoomDetails VALUES ('H02','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'201','AC',1700,'1');
INSERT INTO RoomDetails VALUES ('H02','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'202','NON-AC',1400,'1');
INSERT INTO RoomDetails VALUES ('H02','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'203','AC',1800,'1');
INSERT INTO RoomDetails VALUES ('H02','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'204','NON-AC',1350,'1');

INSERT INTO RoomDetails VALUES ('H03','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'301','AC',1900,'1');
INSERT INTO RoomDetails VALUES ('H03','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'302','NON-AC',1200,'1');
INSERT INTO RoomDetails VALUES ('H03','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'303','AC',1800,'1');
INSERT INTO RoomDetails VALUES ('H03','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'304','NON-AC',1500,'1');

INSERT INTO RoomDetails VALUES ('H04','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'401','AC',1850,'1');
INSERT INTO RoomDetails VALUES ('H04','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'401','NON-AC',1500,'1');
INSERT INTO RoomDetails VALUES ('H04','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'401','AC',1950,'1');
INSERT INTO RoomDetails VALUES ('H04','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'401','NON-AC',1400,'1');

INSERT INTO RoomDetails VALUES ('H05','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'501','AC',2000,'1');
INSERT INTO RoomDetails VALUES ('H05','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'502','NON-AC',1500,'1');
INSERT INTO RoomDetails VALUES ('H05','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'503','AC',2100,'1');
INSERT INTO RoomDetails VALUES ('H05','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'504','NON-AC',1500,'1');

INSERT INTO RoomDetails VALUES ('H07','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'701','AC',2100,'1');
INSERT INTO RoomDetails VALUES ('H07','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'702','NON-AC',1500,'1');
INSERT INTO RoomDetails VALUES ('H07','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'703','NON-AC',1400,'1');
INSERT INTO RoomDetails VALUES ('H07','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'704','AC',2200,'1');

INSERT INTO RoomDetails VALUES ('H08','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'801','NON-AC',1950,'1');
INSERT INTO RoomDetails VALUES ('H08','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'802','NON-AC',1900,'1');
INSERT INTO RoomDetails VALUES ('H08','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'803','AC',2250,'1');
INSERT INTO RoomDetails VALUES ('H08','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'804','AC',2100,'1');

INSERT INTO RoomDetails VALUES ('H09','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'901','AC',2500,'1');
INSERT INTO RoomDetails VALUES ('H09','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'902','AC',2400,'1');
INSERT INTO RoomDetails VALUES ('H09','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'903','NON-AC',2100,'1');
INSERT INTO RoomDetails VALUES ('H09','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'904','NON-AC',2000,'1');

INSERT INTO RoomDetails VALUES ('H10','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'111','AC',2600,'1');
INSERT INTO RoomDetails VALUES ('H10','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'112','NON-AC',2000,'1');
INSERT INTO RoomDetails VALUES ('H10','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'113','NON-AC',2200,'1');
INSERT INTO RoomDetails VALUES ('H10','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'114','AC',2500,'1');

INSERT INTO RoomDetails VALUES ('H11','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'121','AC',2550,'1');
INSERT INTO RoomDetails VALUES ('H11','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'122','AC',2500,'1');
INSERT INTO RoomDetails VALUES ('H11','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'123','AC',2600,'1');
INSERT INTO RoomDetails VALUES ('H11','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'124','AC',2650,'1');

INSERT INTO RoomDetails VALUES ('H12','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'131','NON-AC',2250,'1');
INSERT INTO RoomDetails VALUES ('H12','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'132','NON-AC',2150,'1');
INSERT INTO RoomDetails VALUES ('H12','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'133','AC',2600,'1');
INSERT INTO RoomDetails VALUES ('H12','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'134','NON-AC',2050,'1');

INSERT INTO RoomDetails VALUES ('H13','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'141','AC',2700,'1');
INSERT INTO RoomDetails VALUES ('H13','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'142','AC',2700,'1');
INSERT INTO RoomDetails VALUES ('H13','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'143','AC',2850,'1');
INSERT INTO RoomDetails VALUES ('H13','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'144','NON-AC',2100,'1');

INSERT INTO RoomDetails VALUES ('H14','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'151','AC',3000,'1');
INSERT INTO RoomDetails VALUES ('H14','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'152','AC',2950,'1');
INSERT INTO RoomDetails VALUES ('H14','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'153','AC',2900,'1');
INSERT INTO RoomDetails VALUES ('H14','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'154','AC',2700,'1');

INSERT INTO RoomDetails VALUES ('H15','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'161','AC',2900,'1');
INSERT INTO RoomDetails VALUES ('H15','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'162','AC',2800,'1');
INSERT INTO RoomDetails VALUES ('H15','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'163','AC',2700,'1');
INSERT INTO RoomDetails VALUES ('H15','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'164','AC',2850,'1');

INSERT INTO RoomDetails VALUES ('H16','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'171','AC',3100,'1');
INSERT INTO RoomDetails VALUES ('H16','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'172','AC',3000,'1');
INSERT INTO RoomDetails VALUES ('H16','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'173','AC',2950,'1');
INSERT INTO RoomDetails VALUES ('H16','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'174','AC',3000,'1');

INSERT INTO RoomDetails VALUES ('H17','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'181','AC',2600,'1');
INSERT INTO RoomDetails VALUES ('H17','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'182','AC',2500,'1');
INSERT INTO RoomDetails VALUES ('H17','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'183','AC',2100,'1');
INSERT INTO RoomDetails VALUES ('H17','R'||TO_CHAR((Room_id_Sequence_query.NEXTVAL),'FM00'),'184','AC',2200,'1');