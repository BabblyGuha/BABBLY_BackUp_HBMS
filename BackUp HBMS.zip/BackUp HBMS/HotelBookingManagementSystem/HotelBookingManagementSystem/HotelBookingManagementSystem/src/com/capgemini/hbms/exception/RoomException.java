package com.capgemini.hbms.exception;

public class RoomException extends Exception
{

	private static final long serialVersionUID = 1L;

	public RoomException(String message) {
		super(message);
	}
}
