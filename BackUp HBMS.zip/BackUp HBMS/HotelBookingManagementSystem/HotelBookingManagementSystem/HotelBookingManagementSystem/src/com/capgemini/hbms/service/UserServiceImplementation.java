package com.capgemini.hbms.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.bean.HotelBean;
import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.dao.IUserDao;
import com.capgemini.hbms.dao.UserDaoImplementation;
import com.capgemini.hbms.exception.BookingException;
import com.capgemini.hbms.exception.ConnectionException;
import com.capgemini.hbms.exception.RoomException;
import com.capgemini.hbms.exception.UserException;

public class UserServiceImplementation implements IUserService{

	IUserDao userDao = null;
	//------------------------ 1. HOTEL BOOKING MANAGEMENT SYSTEM ----------------------------------------------
	/*******************************************************************************************************
					- Function Name		:	addBookingDetails
					- Input Parameters	:	BookingDetailsBean bookingDetails
					- Return Type		:	String
					- Throws			:  	ConnectionException, BookingException
					- Author			:	Jhilik Guha
					- Creation Date		:	05/09/2018
					- Description		:	Calling addBookingDetails of dao to add bookings of customers to database
	********************************************************************************************************/
	@Override
	public String addBookingDetails(BookingDetailsBean bookingDetails) throws ConnectionException, BookingException {

		userDao = new UserDaoImplementation();
		return userDao.addBookingDetails(bookingDetails);
	}
	
	//------------------------ 1. HOTEL BOOKING MANAGEMENT SYSTEM ----------------------------------------------
	/*******************************************************************************************************
					- Function Name		:	searchHotels
					- Input Parameters	:	BookingDetailsBean bookingDetails
					- Return Type		:	ArrayList<HotelBean>
					- Throws			:  	ConnectionException, RoomException, BookingException
					- Author			:	Jhilik Guha
					- Creation Date		:	06/09/2018
					- Description		:	Calling searchHotels of dao to display all hotels in a specific city from database
	********************************************************************************************************/
	@Override
	public ArrayList<HotelBean> searchHotels(String city) throws ConnectionException, RoomException, BookingException {
		userDao = new UserDaoImplementation();
		return userDao.searchHotels(city);
	}
	
	//------------------------ 1. HOTEL BOOKING MANAGEMENT SYSTEM ----------------------------------------------
	/*******************************************************************************************************
					- Function Name		:	searchRooms
					- Input Parameters	:	String HotelId
					- Return Type		:	List<RoomDetailsBean>
					- Throws			:  	ConnectionException, RoomException, BookingException
					- Author			:	Jhilik Guha
					- Creation Date		:	06/09/2018
					- Description		:	Calling searchRooms of dao to display all rooms in a specific hotel from database
	********************************************************************************************************/
	@Override
	public List<RoomDetailsBean> searchRooms(String hotelId) throws ConnectionException, RoomException, BookingException
	{
		userDao = new UserDaoImplementation();
		return userDao.searchRooms(hotelId);
	}

	//------------------------ 1. HOTEL BOOKING MANAGEMENT SYSTEM ----------------------------------------------
	/*******************************************************************************************************
				- Function Name		:	viewBookingStatus
				- Input Parameters	:	String roleId,String bookingId
				- Return Type		:	String
				- Throws			:  	ConnectionException, UserException
				- Author			:	Jhilik Guha
				- Creation Date		:	07/09/2018
				- Description		:	Calling viewBookingStatus of dao to display Booking Status w.r.t RoleId and BookingId
	********************************************************************************************************/
	@Override
	public String viewBookingStatus(String roleId,String bookingId) throws ConnectionException, UserException {

		userDao = new UserDaoImplementation();
		return userDao.viewBookingStatus(roleId,bookingId);
		
	}

	//------------------------ 1. HOTEL BOOKING MANAGEMENT SYSTEM ----------------------------------------------
	/*******************************************************************************************************
				- Function Name		:	viewAllBookingStatus
				- Input Parameters	:	String userId
				- Return Type		:	List<String>
				- Throws			:  	ConnectionException, UserException
				- Author			:	Jhilik Guha
				- Creation Date		:	08/09/2018
				- Description		:	Calling viewAllBookingStatus of dao to display the booking status of all customers
	********************************************************************************************************/
	
	@Override
	public List<String> viewAllBookingStatus(String bookingId) throws UserException, ConnectionException {

		userDao = new UserDaoImplementation();
		return userDao.viewAllBookingStatus(bookingId);
	}

	//------------------------ 1. HOTEL BOOKING MANAGEMENT SYSTEM ----------------------------------------------
	/*******************************************************************************************************
					- Function Name		:	roomExistence
					- Input Parameters	:	String roomId
					- Return Type		:	boolean
					- Throws			:  	ConnectionException, BookingException
					- Author			:	Jhilik Guha
					- Creation Date		:	07/09/2018
					- Description		:	Calling roomExistence of dao to check for the existence of a room requested by the user from database
	********************************************************************************************************/
	@Override
	public boolean roomExistence(String roomId) throws ConnectionException, BookingException {

		userDao = new UserDaoImplementation();
		return userDao.roomExistence(roomId);
	}

	//------------------------ 1. HOTEL BOOKING MANAGEMENT SYSTEM ----------------------------------------------
	/*******************************************************************************************************
								- Function Name		:	userExistence
								- Input Parameters	:	String userId
								- Return Type		:	boolean
								- Throws			:  	ConnectionException, BookingException
								- Author			:	Jhilik Guha
								- Creation Date		:	07/09/2018
								- Description		:	Calling userExistence of dao to check for the existence of the user from database
	********************************************************************************************************/
	@Override
	public boolean userExistence(String userId) throws ConnectionException, BookingException {

		userDao = new UserDaoImplementation();
		return userDao.userExistence(userId);
	}

	//------------------------ 1. HOTEL BOOKING MANAGEMENT SYSTEM ----------------------------------------------
	/*******************************************************************************************************
						- Function Name		:	dateCheckOut
						- Input Parameters	:	LocalDate bookFrom, LocalDate bookTo
						- Return Type		:	String
						- Throws			:  	No Exception is thrown
						- Author			:	Jhilik Guha
						- Creation Date		:	07/09/2018
						- Description		:	Calling dateCheckOut of dao to check the validity of check out date
	********************************************************************************************************/
	@Override
	public String dateCheckOut(LocalDate bookingFrom, LocalDate bookingTo) {

		userDao = new UserDaoImplementation();
		return userDao.dateCheckOut(bookingFrom,bookingTo);
	}

	//------------------------ 1. HOTEL BOOKING MANAGEMENT SYSTEM ----------------------------------------------
	/*******************************************************************************************************
					- Function Name		:	roomAvailability
					- Input Parameters	:	String roomId, LocalDate bookFrom, LocalDate bookTo
					- Return Type		:	boolean
					- Throws			:  	ConnectionException, BookingException
					- Author			:	Jhilik Guha
					- Creation Date		:	07/09/2018
					- Description		:	Calling roomAvailability of dao to check the check for the availability of a room requested by the user from database
	********************************************************************************************************/
	@Override
	public boolean roomAvailability(String roomId, LocalDate bookingFrom,LocalDate bookingTo) throws ConnectionException, BookingException {

		userDao = new UserDaoImplementation();
		return userDao.roomAvailability(roomId,bookingFrom,bookingTo);
	}

	//------------------------ 1. HOTEL BOOKING MANAGEMENT SYSTEM ----------------------------------------------
	/*******************************************************************************************************
							- Function Name		:	dateCheckIn
							- Input Parameters	:	LocalDate bookFrom
							- Return Type		:	String
							- Throws			:  	No Exception are thrown
							- Author			:	Jhilik Guha
							- Creation Date		:	08/09/2018
							- Description		:	Calling dateCheckIn of dao to check the check out date validity database
	********************************************************************************************************/
	@Override
	public String dateCheckIn(LocalDate bookingFrom) {

		userDao = new UserDaoImplementation();
		return userDao.dateCheckIn(bookingFrom);
	}

	//------------------------ 1. HOTEL BOOKING MANAGEMENT SYSTEM ----------------------------------------------
	/*******************************************************************************************************
						- Function Name		:	displayCities
						- Input Parameters	:	No Parameters
						- Return Type		:	List<String>
						- Throws			:  	UserException, ConnectionException
						- Author			:	Jhilik Guha
						- Creation Date		:	08/09/2018
						- Description		:	Calling displayCities() of dao to display all the cities where hotel facilities are there
	********************************************************************************************************/
	@Override
	public List<String> displayCities() throws UserException, ConnectionException {

		userDao = new UserDaoImplementation();
		return userDao.displayCities();
	}
	
	//------------------------ 1. HOTEL BOOKING MANAGEMENT SYSTEM ----------------------------------------------
	/*******************************************************************************************************
			- Function Name		:	updateRoomAvailability
			- Input Parameters	:	No Input Parameters
			- Return Type		:	void
			- Throws			:  	BookingException
			- Author			:	Jhilik Guha
			- Creation Date		:	06/09/2018
			- Description		:	Calling updateRoomAvailability() of Dao for Updating the availability of rooms
	 * @throws BookingException 
	 * @throws ConnectionException 
	********************************************************************************************************/
		
		@Override
		public void updateRoomAvailability() throws BookingException, ConnectionException {

			userDao = new UserDaoImplementation();
			userDao.updateRoomAvailability();
			
		}
	
	/*****************************************************************************************************
	 *						<<<<<<<<<<<<<  Validation Methods  >>>>>>>>>>>>>
	 *****************************************************************************************************/
	
	//Validate Booking ID
	@Override
	public boolean validateBookingId(String bookingId) {

		Pattern p = Pattern.compile("[B][0-9]{2}");
		Matcher m = p.matcher(bookingId);
		return m.matches();
	}
	
	//Validate Date
	@Override
	public boolean validateDate(String date) {

		Pattern p = Pattern.compile("[0-9]{2}/[0-9]{2}/[0-9]{4}");
		Matcher m = p.matcher(date);
		return m.matches();
	}

	//Validate Number of Adults
	@Override
	public boolean validateNoOfAdults(String adults) {

		Pattern p = Pattern.compile("[0-9]{1,2}");
		Matcher m = p.matcher(adults);
		return m.matches();
	}

	//Validate Number of Children
	@Override
	public boolean validateNoOfChildren(String childrens) {

		Pattern p = Pattern.compile("[0-9]{1,3}");
		Matcher m = p.matcher(childrens);
		return m.matches();	
		}

	//Validate User ID
	@Override
	public boolean validateUserId(String userId) {

		Pattern p = Pattern.compile("[C][0-9]{1,3}");
		Matcher m = p.matcher(userId);
		return m.matches();
	}
}
